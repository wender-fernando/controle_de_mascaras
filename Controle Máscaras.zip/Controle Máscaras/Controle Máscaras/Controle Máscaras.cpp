// Controle Máscaras.cpp : Este arquivo contém a função 'main'. A execução do programa começa e termina ali.
//

#include <iostream>
#include <locale.h>

using namespace std;
int codMascara, qtdMascara;

int main()

{
    setlocale(LC_ALL, "Portuguese");

    cout << "Hello Mask!\n";
    cout << "Digite o código da máscara: \n MÁSCARA SIMPLES - 1 \n MÁSCARA BORDADA - 2 \n MÁSCARA 3D - 3 \n MÁSCARA 3D LESE - 4 \n MÁSCARA NEOPRENE - 5 \n MÁSCARA N95 - 6 \n MÁSCARA DESCARTÁVEL (pct 50un.) - 7 \n";
    cin >> codMascara;
    cout << "Digite a quantidade de máscaras \n";
    cin >> qtdMascara;

    switch (codMascara) {
    case 1: cout << "O valor a ser pago é: " << qtdMascara * 5.00;
         break;
    case 2: cout << "O valor a ser pago é: " << qtdMascara * 8.00;
         break;
    case 3: cout << "O valor a ser pago é: " << qtdMascara * 10.00;
        break;
    case 4: cout << "O valor a ser pago é: " << qtdMascara * 12.00;
        break;
    case 5: cout << "O valor a ser pago é: " << qtdMascara * 7.00;
        break;
    case 6: cout << "O valor a ser pago é: " << qtdMascara * 17.00;
        break;
    case 7: cout << "O valor a ser pago é: " << qtdMascara * 20.00;
        break;
    default: cout << R"(Código inválido, verifique e tente novamente.)";
    }
}

// Executar programa: Ctrl + F5 ou Menu Depurar > Iniciar Sem Depuração
// Depurar programa: F5 ou menu Depurar > Iniciar Depuração

// Dicas para Começar: 
//   1. Use a janela do Gerenciador de Soluções para adicionar/gerenciar arquivos
//   2. Use a janela do Team Explorer para conectar-se ao controle do código-fonte
//   3. Use a janela de Saída para ver mensagens de saída do build e outras mensagens
//   4. Use a janela Lista de Erros para exibir erros
//   5. Ir Para o Projeto > Adicionar Novo Item para criar novos arquivos de código, ou Projeto > Adicionar Item Existente para adicionar arquivos de código existentes ao projeto
//   6. No futuro, para abrir este projeto novamente, vá para Arquivo > Abrir > Projeto e selecione o arquivo. sln
